using loginapi.ViewModel;
using loginapi.Entities;
namespace loginapi.IServices;

public interface IProductService{
    List<Product> GetProduct();
}