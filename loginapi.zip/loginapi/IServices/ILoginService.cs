using loginapi.ViewModel;
namespace loginapi.IServices;

public interface ILoginService{
    LoginResult ValidateUser(LoginViewModel loginCredential);
}