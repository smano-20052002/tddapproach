namespace loginapi.ViewModel;

public class LoginViewModel{
    public string UserCredentials{get;set;}
    public string Password{get;set;}
}