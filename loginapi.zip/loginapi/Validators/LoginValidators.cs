using FluentValidation;
using FluentValidation;
using loginapi.ViewModel;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;


public class LoginValidators:AbstractValidator<LoginViewModel>{
    public LoginValidators(){
        RuleFor(x=>x.UserCredentials).NotEmpty().WithMessage("User Email or Mobile Number is required").Must(BeValidEmailOrMobileNumber).WithMessage("Please enter a valid email address or mobile number");
        RuleFor(x=>x.Password).NotEmpty().WithMessage("Password is required");
    }
    private bool BeValidEmailOrMobileNumber(string value){
        if(this.BeValidEmail(value)){
            return true;
        }else if(this.BeValidMobileNumber(value)){
            return true;
        }
        return false;
        
    }
    private bool BeValidEmail(string email){
        return Regex.IsMatch(email,@"^([\w\.\-]+)@([\w]+)((\.(\w){2,3})+)$");
        
    }
    private bool BeValidMobileNumber(string mobileNumber){
        return Regex.IsMatch(mobileNumber,@"^[6-9]{1}\d{9}$");
        
    }

}