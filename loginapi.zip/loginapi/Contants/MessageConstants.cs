namespace loginapi.Constants;

public static class MessageConstants{

    public const string MsgLoginSuccess="Login Successfully";
    public const string MsgInternalServerError="Internal Server Error! Please try again later";
    public const string MsgValidationFailure="Internal Server Error! Please try again later";
    public const string MsgLoginFailureInvalidPassword="Invalid Password";
    public const string MsgLoginFailureInvalidUserId="Invalid User";
    public const string MsgNoData="No Data";
    public const string MsgSuccess="Success";

}