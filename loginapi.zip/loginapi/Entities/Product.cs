namespace loginapi.Entities;
public class Product{
    public Guid ProductId{get;set;}
    public string? ProductName{get;set;}
    public int ProductPrice{get;set;}
}