using loginapi.Entities;
namespace loginapi.IRepository;
public interface IUserRepository
{
    User GetUserByEmailOrMobile(string userCredentials);
}