using loginapi.Entities;
namespace loginapi.IRepository;
public interface IProductRepository
{
    List<Product> GetProduct();
}