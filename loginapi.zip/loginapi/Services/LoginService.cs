using loginapi.IServices;
using loginapi.ViewModel;
using loginapi.IRepository;
using loginapi.Constants;
namespace loginapi.Services;

public class LoginService : ILoginService
{
    private readonly IUserRepository _userRepository;
 
    public LoginService(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }
 
    public LoginResult ValidateUser(LoginViewModel loginCredential)
    {
        var user = _userRepository.GetUserByEmailOrMobile(loginCredential.UserCredentials);
 
        if (user == null)
        {
            return new LoginResult
            {
                IsSuccess = false,
                Message = MessageConstants.MsgLoginFailureInvalidUserId
            };
        }

        if (user.Password == loginCredential.Password)
        {
            return new LoginResult
            {
                IsSuccess = true,
                Message = MessageConstants.MsgLoginSuccess
            };
        }
        else
        {
            return new LoginResult
            {
                IsSuccess = false,
                Message = MessageConstants.MsgLoginFailureInvalidPassword
            };
        }

    }
}