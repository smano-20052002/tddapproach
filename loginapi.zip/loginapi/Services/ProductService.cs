using loginapi.IServices;
using loginapi.IRepository;
using loginapi.Entities;
namespace loginapi.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;
 
    public ProductService(IProductRepository productRepository)
    {
        _productRepository = productRepository;
    }
 
    public List<Product> GetProduct()
    {
       return _productRepository.GetProduct();
    }
}