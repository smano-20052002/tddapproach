using loginapi.DataContext;
using Microsoft.EntityFrameworkCore;
using loginapi.IServices;
using loginapi.Services;

using loginapi.Repository;

using loginapi.IRepository;

using FluentValidation.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers().AddFluentValidation(v=>v.RegisterValidatorsFromAssemblyContaining<LoginValidators>());

builder.Services.AddCors(options=>options.AddPolicy(

    name:"_SpecificOrigins",

    policy=>policy.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()

)
);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

var ConnectionString = builder.Configuration.GetConnectionString("DefaultConnections");

builder.Services.AddDbContext<AppDbContext>(options=>options.UseMySql(ConnectionString,new MySqlServerVersion(new Version())));

builder.Services.AddScoped<ILoginService,LoginService>();

builder.Services.AddScoped<IUserRepository,UserRepository>();

builder.Services.AddScoped<IProductService,ProductService>();

builder.Services.AddScoped<IProductRepository,ProductRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();

    app.UseSwaggerUI();
}

app.UseCors("_SpecificOrigins");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
