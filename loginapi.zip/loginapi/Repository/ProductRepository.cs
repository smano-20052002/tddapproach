using loginapi.IRepository;
using loginapi.DataContext;
using loginapi.Entities;
namespace loginapi.Repository;

public class ProductRepository : IProductRepository
{
    private readonly AppDbContext _context;
 
    public ProductRepository(AppDbContext context)
    {
        _context = context;
    }
 
    public List<Product> GetProduct()
    {
        return _context.Products
            .ToList();
    }
}