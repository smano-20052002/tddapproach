using loginapi.IRepository;
using loginapi.DataContext;
using loginapi.Entities;
namespace loginapi.Repository;

public class UserRepository : IUserRepository
{
    private readonly AppDbContext _context;
 
    public UserRepository(AppDbContext context)
    {
        _context = context;
    }
 
    public User GetUserByEmailOrMobile(string userCredentials)
    {
        return _context.Users
            .FirstOrDefault(u => u.Email == userCredentials || u.MobileNumber == userCredentials);
    }
}