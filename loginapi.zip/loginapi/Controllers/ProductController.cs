using Microsoft.AspNetCore.Mvc;
using loginapi.ViewModel;
using loginapi.DataContext;
using loginapi.Constants;
using loginapi.IServices;
namespace loginapi.Controllers;

[ApiController]
[Route("[controller]")]

public class ProductController : BaseController
{
    private readonly IProductService _productService;
    public ProductController(IProductService productService)
    {
        _productService = productService;
    }
    [HttpGet]
    public IActionResult GetProduct()
    {

        var productlist = _productService.GetProduct();
        if (productlist.Any())
        {
            return Ok(CreateSuccessResponse(MessageConstants.MsgSuccess, productlist));
        }
        return Ok(CreateSuccessResponse(MessageConstants.MsgNoData, productlist));

    }
}