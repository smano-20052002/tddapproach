using Microsoft.AspNetCore.Mvc;
using loginapi.ViewModel;
using loginapi.DataContext;
using loginapi.Constants;
using loginapi.IServices;
namespace loginapi.Controllers;

[ApiController]
[Route("[controller]")]

public class LoginController:BaseController{
    private readonly ILoginService _loginService;
    public LoginController(ILoginService loginService){
        
        _loginService=loginService;
    }
   [HttpPost]
public IActionResult Login(LoginViewModel loginCredential)
{
    if (!ModelState.IsValid)
    {
        return BadRequest(ModelState);
    }
 
    var loginResult = _loginService.ValidateUser(loginCredential);
 
    if (loginResult.IsSuccess)
    {
        return Ok(CreateSuccessResponse(MessageConstants.MsgLoginSuccess, null));
    }
 
    return Ok(CreateSuccessResponse(loginResult.Message, null));
}
}