using Microsoft.AspNetCore.Mvc;
using loginapi.ViewModel;
using loginapi.Constants;
namespace loginapi.Controllers;

[ApiController]
[Route("[controller]/[action]")]

public class BaseController:ControllerBase{

    public BaseController(){

    }

    [NonAction]
    public ApiResponse CreateSuccessResponse(string message,object data){
        return new ApiResponse(){
            StatusCode=200,
            Message=message,
            Data=data
        };
    }
    
   [NonAction]
    public ApiResponse CreateFailureResponse(string message,object data){
        return new ApiResponse(){
            StatusCode=400,
            Message=message,
            Data=data
        };
    }
}