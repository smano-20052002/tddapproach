using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using loginapi.Controllers;
using loginapi.DataContext;
using loginapi.ViewModel;
using loginapi.Entities;
using Microsoft.AspNetCore.Mvc;
using loginapi.Controllers;
using loginapi.IRepository;
using loginapi.Repository;

namespace loginapitest
{
    public class ProductRepositoryTest
    {
        private AppDbContext _appDbContext;
        private IProductRepository? _productRepository;
        private List<Product> _product;



        [SetUp]
        public void Setup()
        {

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>()
         .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString());

            _appDbContext = new AppDbContext(optionsBuilder.Options);
            _productRepository = new ProductRepository(_appDbContext);

            _product = new List<Product>(){
                new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap",
                ProductPrice=90
            },
            new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap1",
                ProductPrice=91
            }
            };
            _appDbContext.Products.AddRange(_product);
            _appDbContext.SaveChanges();

        }

        [Test]
        public void GetProductTest_return_Data()
        {
            //arrange
            //act
            var result=_productRepository.GetProduct();
            //assert
            Assert.IsInstanceOf<List<Product>>(result);
            Assert.AreEqual(_product,result as List<Product>);

            
            
        }

        

        


        

        [TearDown]
        public void TearDown()
        {
            _appDbContext.Database.EnsureDeleted();
            _appDbContext.Dispose();
        }
    }
}
