
using loginapi.Controllers;
using loginapi.Constants;
using loginapi.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Moq;
using loginapi.IServices;
using MySqlX.XDevAPI.Common;

namespace loginapitest
{
    public class LoginControllerTest
    {
        private Mock<ILoginService> _loginServiceMock;
        private LoginController _loginController;



        [SetUp]
        public void Setup()
        {
              _loginServiceMock = new Mock<ILoginService>();
            _loginController = new LoginController(_loginServiceMock.Object);

        }

        // [Test]
        // public void Login_InvalidModel_ReturnsBadRequest()
        // {
        //     // Arrange
        //     var invalidLoginCredential = new LoginViewModel(){
        //         UserCredentials=String.Empty,
        //         Password=String.Empty
        //     }; 
 
        //     // Act
        //     var result = _loginController.Login(invalidLoginCredential);
 
        //     // Assert
        //     Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            
        // }
 
        [Test]
        public void Login_ValidCredentials_ReturnsSuccessMessage()
        {
            // Arrange
            var validLoginCredential = new LoginViewModel { UserCredentials = "testuser", Password = "password123" };
            _loginServiceMock.Setup(service => service.ValidateUser(validLoginCredential))
                .Returns(new LoginResult { IsSuccess = true, Message = MessageConstants.MsgLoginSuccess });
 
            // Act
            var result = _loginController.Login(validLoginCredential);
 
            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(MessageConstants.MsgLoginSuccess, (okResult.Value as ApiResponse).Message);
        }
 
        [Test]
        public void Login_InvalidCredentials_ReturnsFailureMessage()
        {
            // Arrange
            var invalidLoginCredential = new LoginViewModel { UserCredentials = "testuser", Password = "wrongpassword" };
            _loginServiceMock.Setup(service => service.ValidateUser(invalidLoginCredential))
                .Returns(new LoginResult { IsSuccess = false, Message = MessageConstants.MsgLoginFailureInvalidPassword });
 
            // Act
            var result = _loginController.Login(invalidLoginCredential);
 
            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(MessageConstants.MsgLoginFailureInvalidPassword,(okResult.Value as ApiResponse)?.Message);
        }


        [TearDown]
        public void TearDown()
        {
            
        }
    }
}
