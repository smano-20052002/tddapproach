
using loginapi.ViewModel;
using loginapi.Entities;
using Moq;
using loginapi.Constants;
using loginapi.IRepository;
using loginapi.IServices;
using loginapi.Services;

namespace loginapitest
{
    public class LoginServiceTest
    {

        private Mock<IUserRepository> _userRepositoryMock;
        private ILoginService _loginService;


        [SetUp]
        public void Setup()
        {

            _userRepositoryMock = new Mock<IUserRepository>();
            _loginService = new LoginService(_userRepositoryMock.Object);

        }

        [Test]
        public void ValidateUser_InvalidUser_ReturnsFailure()
        {
            // Arrange
            var loginCredential = new LoginViewModel { UserCredentials = "invalidUser", Password = "password123" };

            _userRepositoryMock.Setup(repo => repo.GetUserByEmailOrMobile(loginCredential.UserCredentials))
                .Returns((User)null);

            // Act
            var result = _loginService.ValidateUser(loginCredential);

            // Assert
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(MessageConstants.MsgLoginFailureInvalidUserId, result.Message);
        }

        [Test]
        public void ValidateUser_InvalidPassword_ReturnsFailure()
        {
            // Arrange
            var loginCredential = new LoginViewModel { UserCredentials = "testuser", Password = "wrongpassword" };
            var user = new User
            {
                UserId = Guid.NewGuid(),
                Email = "smano4570@gmail.com",
                Password = "smano@20052002",
                Name = "smano",
                MobileNumber = "9876543210"
            };
            _userRepositoryMock.Setup(repo => repo.GetUserByEmailOrMobile(loginCredential.UserCredentials))
                .Returns(user);

            // Act
            var result = _loginService.ValidateUser(loginCredential);

            // Assert
            Assert.IsFalse(result.IsSuccess);
            Assert.AreEqual(MessageConstants.MsgLoginFailureInvalidPassword, result.Message);
            
        }

        [Test]
        public void ValidateUser_ValidEmailCredentials_ReturnsSuccess()
        {
            // Arrange
            var loginCredential = new LoginViewModel { UserCredentials = "smano4570@gmail.com", Password = "smano@20052002" };
            var user = new User
            {
                UserId = Guid.NewGuid(),
                Email = "smano4570@gmail.com",
                Password = "smano@20052002",
                Name = "smano",
                MobileNumber = "9876543210"
            };
            _userRepositoryMock.Setup(repo => repo.GetUserByEmailOrMobile(loginCredential.UserCredentials))
                .Returns(user);

            // Act
            var result = _loginService.ValidateUser(loginCredential);

            // Assert
            Assert.IsTrue(result.IsSuccess);

            Assert.AreEqual(MessageConstants.MsgLoginSuccess,result.Message);
        }
         [Test]
        public void ValidateUser_ValidMobileNumberCredentials_ReturnsSuccess()
        {
            // Arrange
            var loginCredential = new LoginViewModel { UserCredentials = "9876543210", Password = "smano@20052002" };
            var user = new User
            {
                UserId = Guid.NewGuid(),
                Email = "smano4570@gmail.com",
                Password = "smano@20052002",
                Name = "smano",
                MobileNumber = "9876543210"
            };
            _userRepositoryMock.Setup(repo => repo.GetUserByEmailOrMobile(loginCredential.UserCredentials))
                .Returns(user);

            // Act
            var result = _loginService.ValidateUser(loginCredential);

            // Assert
            Assert.IsTrue(result.IsSuccess);

            Assert.AreEqual(MessageConstants.MsgLoginSuccess,result.Message);
        }


    }
}
