using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using loginapi.Controllers;
using loginapi.DataContext;
using loginapi.ViewModel;
using loginapi.Entities;
using Microsoft.AspNetCore.Mvc;
using loginapi.Controllers;
using loginapi.Repository;

namespace loginapitest
{
    public class UserRepositoryTest
    {
        private AppDbContext _appDbContext;
        private UserRepository? _userRepository;
        private User _user;



        [SetUp]
        public void Setup()
        {

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>()
         .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString());



            _appDbContext = new AppDbContext(optionsBuilder.Options);
            _userRepository = new UserRepository(_appDbContext);



            _user = new User()
            {
                UserId = Guid.NewGuid(),
                Email = "smano4570@gmail.com",
                Password = "smano@20052002",
                Name = "smano",
                MobileNumber = "9876543210"
            };

            _appDbContext.Users.Add(_user);
            _appDbContext.SaveChanges();

        }



        [Test]
        public void GetUserByEmailOrMobile_with_CorrectMobileNumber_return_User_Value()
        {
            // Arrange
            string UserCredentials = "9876543210"; 

            // Act
            var result = _userRepository.GetUserByEmailOrMobile(UserCredentials) ;

            // Assert
            Assert.IsInstanceOf<User>(result);
            Assert.AreEqual(_user,result);
            
        }



       [Test]
        public void GetUserByEmailOrMobile_with_CorrectEmail_return_User_Value()
        {
            // Arrange
           string UserCredentials = "smano4570@gmail.com";

            // Act
            var result = _userRepository.GetUserByEmailOrMobile(UserCredentials);

            // Assert
            Assert.IsInstanceOf<User>(result);
            Assert.AreEqual(_user,result as User);
            
        }



        [Test]
        public void GetUserByEmailOrMobile_with_InCorrectMobileNumber_return_Null_Value()
        {
            // Arrange
            string UserCredentials = "0000000000";

            // Act
            var result = _userRepository.GetUserByEmailOrMobile(UserCredentials);

            // Assert
            Assert.AreEqual(null,result);
            
        }



       [Test]
        public void GetUserByEmailOrMobile_with_InCorrectEmail_return_Null_Value()
        {
            // Arrange
            string UserCredentials = "incorrectemail@gmail.com";

            // Act
            var result = _userRepository.GetUserByEmailOrMobile(UserCredentials);

            // Assert
            Assert.AreEqual(null,result);
            
        }


        [TearDown]
        public void TearDown()
        {
            _appDbContext.Database.EnsureDeleted();
            _appDbContext.Dispose();
        }
    }
}
