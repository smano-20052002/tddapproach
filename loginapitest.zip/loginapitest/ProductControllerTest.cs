using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using loginapi.Controllers;
using loginapi.DataContext;
using loginapi.ViewModel;
using loginapi.Entities;
using Microsoft.AspNetCore.Mvc;
using loginapi.IServices;
using loginapi.Controllers;
using Moq;
using loginapi.Constants;

namespace loginapitest
{
    public class ProductControllerTest
    {
        

        private Mock<IProductService> _productServiceMock;
        private ProductController _productController;

        [SetUp]
        public void Setup()
        {

            _productServiceMock = new Mock<IProductService>();
            _productController = new ProductController(_productServiceMock.Object);

        }
        
        [Test]
        public void GetProductTest_return_OkResult_With_Data()
        {
            //arrange
            _productServiceMock.Setup(service => service.GetProduct())
                .Returns(new List<Product> { 
                     new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap",
                ProductPrice=90
            },
            new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap1",
                ProductPrice=91
            }
                 });
 
            
            //act
            var result=_productController.GetProduct();
            //assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(MessageConstants.MsgSuccess, (okResult.Value as ApiResponse).Message);
            Assert.IsInstanceOf<List<Product>>((okResult.Value as ApiResponse).Data);
            
            
            
        }

        [Test]
        public void GetProductTest_return_No_Data_Msg()
        {
            //arrange
             _productServiceMock.Setup(service => service.GetProduct())
                .Returns(new List<Product>());
            //act
            var result=_productController.GetProduct();
            //assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.AreEqual(MessageConstants.MsgNoData, (okResult.Value as ApiResponse).Message);
            
            
        }



        [TearDown]
        public void TearDown()
        {
           
        }
    }
}
