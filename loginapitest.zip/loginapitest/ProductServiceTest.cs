using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using loginapi.Controllers;
using loginapi.DataContext;
using loginapi.ViewModel;
using loginapi.Entities;
using Microsoft.AspNetCore.Mvc;
using loginapi.Controllers;
using loginapi.IServices;
using loginapi.Services;
using loginapi.IRepository;
using Moq;
namespace loginapitest
{
    public class ProductServiceTest
    {
     
        private Mock<IProductRepository> _productRepositoryMock;
        private IProductService _productService;

        [SetUp]
        public void Setup()
        {

            _productRepositoryMock = new Mock<IProductRepository>();
            _productService = new ProductService(_productRepositoryMock.Object);

        }
        
        [Test]
        public void GetProductTest_return_Data()
        {
            //arrange
            _productRepositoryMock.Setup(service => service.GetProduct())
                .Returns(new List<Product> { 
                     new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap",
                ProductPrice=90
            },
            new Product()
            {
                ProductId=Guid.NewGuid(),
                ProductName="Soap1",
                ProductPrice=91
            }
                 });
 
            
            //act
            var result=_productService.GetProduct();
            //assert
            Assert.IsInstanceOf<List<Product>>(result);
            
            
        }

        



        
      
    }
}
